import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { signUserUp } from '../../actions/userActions';

class RegisterForm extends Component {
    state = {
        username: '',
        email: '',
        password: '',
        passwordConfirm: '',
    };

    handleOnChange = (e) => {
        e.persist();
        this.setState(() => ({
            [e.target.name]: e.target.value,
        }));
    };

    onSubmit = (e) => {
        e.preventDefault();
        this.props.signUserUp(this.state);
    };

    render() {
        return (
            <form onSubmit={this.onSubmit}>
                <div className='register_form'>
                    <h2>Register</h2>
                    <input
                        type='text'
                        name='username'
                        placeholder='Username'
                        value={this.state.username}
                        onChange={this.handleOnChange}
                    />
                    <input
                        type='text'
                        placeholder='E-Mail'
                        name='email'
                        value={this.state.email}
                        onChange={this.handleOnChange}
                    />
                    <input
                        type='password'
                        placeholder='Password'
                        onChange={this.handleOnChange}
                    />

                    <input
                        type='password'
                        placeholder='Confirm Password'
                        onChange={this.handleOnChange}
                    />

                    <button
                        type='submit'
                        className='formButton'
                        onClick={(e) => {
                            e.preventDefault();
                        }}
                    >
                        Register
                    </button>

                    <span className='signup'>
                        Have account?{' '}
                        <Link className='login' to='/login'>
                            Sign In
                        </Link>
                    </span>
                </div>
            </form>
        );
    }
}

export default RegisterForm;
