import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { signUserUp } from '../../actions/userActions';
import { useAuth0 } from '@auth0/auth0-react';

class RegisterForm extends Component {
    state = {
        username: '',
        email: '',
        password: '',
        passwordConfirm: '',
    };

    handleOnChange = (e) => {
        e.persist();
        this.setState(() => ({
            [e.target.name]: e.target.value,
        }));
    };

    onSubmit = (e) => {
        e.preventDefault();
        console.log(this.state);
        this.props.signUserUp(this.state);
    };

    render() {
        return (
            <form onSubmit={this.onSubmit}>
                <div className='register_form'>
                    <h2>Register</h2>
                    <input
                        type='text'
                        name='username'
                        placeholder='Username'
                        value={this.state.username}
                        onChange={this.handleOnChange}
                    />
                    <input
                        type='text'
                        placeholder='E-Mail'
                        name='email'
                        value={this.state.email}
                        onChange={this.handleOnChange}
                    />
                    <input
                        type='password'
                        name='password'
                        value={this.state.password}
                        placeholder='Password'
                        onChange={this.handleOnChange}
                    />

                    <input
                        type='password'
                        name='passwordConfirm'
                        value={this.state.passwordConfirm}
                        placeholder='Confirm Password'
                        onChange={this.handleOnChange}
                    />

                    <button
                        type='submit'
                        className='formButton'
                        value='Register'
                    >
                        Register
                    </button>

                    <span className='signup'>
                        Have account?{' '}
                        <Link className='login' to='/login'>
                            Sign In
                        </Link>
                    </span>
                </div>
            </form>
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        signUserUp: (userInfo) => dispatch(signUserUp(userInfo)),
    };
};

export default connect(null, mapDispatchToProps)(RegisterForm);
