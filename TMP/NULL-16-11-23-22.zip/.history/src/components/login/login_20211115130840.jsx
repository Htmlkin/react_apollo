import { Form } from '../form/form';
import { useDispatch } from 'react';

const Login = () => {
    return <div></div>;
};

export { Login };
