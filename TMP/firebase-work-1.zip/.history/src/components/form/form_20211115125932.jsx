import { useState } from 'react';

const Form = () => {
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    return <div></div>;
};

export { Form };
