import React from 'react';
import './login-page.css';

const LoginPage = () => {
    return (
        <main id='loginContent'>
            <section>
                <div id='enter_form'>
                    <input type='text' value='' />
                    <input type='text' value='' />
                </div>
            </section>
        </main>
    );
};

export default LoginPage;
