import React from 'react';
import 'private.css';

const PrivatePage = () => {
    return (
        <>
            <h1>This Is Private Zone</h1>
        </>
    );
};

export default PrivatePage;
