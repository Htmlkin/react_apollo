import React from 'react';
import './private.css';
