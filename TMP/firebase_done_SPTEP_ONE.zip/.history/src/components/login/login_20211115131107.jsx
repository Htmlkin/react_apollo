import { Form } from '../form/form';
import { useDispatch } from 'react-redux';
import { setUser } from '../../stotre/slices/userSlice';

const Login = () => {
    const dispatch = useDispatch();

    return <div></div>;
};

export { Login };
