import React from 'react';
import './login-page.css';

const LoginPage = () => {
    return (
        <main id='loginContent'>
            <section>
                <h1>Hello!!! This Is Login Page</h1>
            </section>
        </main>
    );
};

export default LoginPage;
