export function userSignupRequest(userData) {
    return (dispatch) => {
        return axios.post('/api/user');
    };
}
