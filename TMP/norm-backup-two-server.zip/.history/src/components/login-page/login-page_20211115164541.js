import React from 'react';
import './login-page.css';

const LoginPage = () => {
    return (
        <main id='loginContent'>
            <section></section>
        </main>
    );
};

export default LoginPage;
