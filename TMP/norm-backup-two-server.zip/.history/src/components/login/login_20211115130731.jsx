import { Form } from '../form/form';

const Login = () => {
    return <div></div>;
};

export { Login };
