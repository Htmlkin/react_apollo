import React from 'react';
import './register-page.css';

const RegisterPage = () => {
    return (
        <main id='registerContent'>
            <section>
                <h1>New User</h1>
            </section>
        </main>
    );
};

export default RegisterPagePage;
