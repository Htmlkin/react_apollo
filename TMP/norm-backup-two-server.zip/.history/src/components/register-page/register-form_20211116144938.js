import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class RegisterForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            email: '',
            password: '',
            confirmPassword: '',
        };

        this.onChange = this.onChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }

    onChange(e) {
        this.setState({ [e.target.name]: e.target.value });
    }

    onSubmit(e) {
        e.preventDefault();
        console.log(this.state);
        this.props.userSignupRequest(this.state);
    }

    render() {
        const { username, email, password, confirmPassword } = this.state;

        return (
            <form onSubmit={this.onSubmit}>
                <div className='register_form'>
                    <h2>Register</h2>
                    <input
                        value={username}
                        name='username'
                        type='text'
                        placeholder='Username'
                        // onChange={(e) => console.log(e.target.value)}
                        onChange={this.onChange}
                    />
                    <input
                        value={email}
                        name='email'
                        type='text'
                        placeholder='E-Mail'
                        onChange={this.onChange}
                    />
                    <input
                        value={password}
                        type='password'
                        name='password'
                        placeholder='Password'
                        onChange={this.onChange}
                    />

                    <input
                        value={confirmPassword}
                        type='password'
                        name='confirmPassword'
                        placeholder='Confirm Password'
                        onChange={this.onChange}
                    />

                    <button
                        type='submit'
                        className='formButton'
                        // onClick={(e) => {
                        //     e.preventDefault();
                        // }}
                    >
                        Register
                    </button>

                    <span className='signup'>
                        Have account?{' '}
                        <Link className='login' to='/login'>
                            Sign In
                        </Link>
                    </span>
                </div>
            </form>
        );
    }
}

RegisterForm.propTypes = {
    userSignupRequest: React.PropTypes.func.isRequired,
};

export default RegisterForm;
