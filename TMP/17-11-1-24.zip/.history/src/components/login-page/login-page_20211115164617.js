import React from 'react';
import './login-page.css';

const LoginPage = () => {
    return (
        <main id='loginContent'>
            <section>
                <h1>Private Room</h1>
            </section>
        </main>
    );
};

export default LoginPage;
