import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { fetchUser } from '../../actions/userActions';

class LoginForm extends Component {
    state = {
        username: '',
        password: '',
    };

    handleOnChange = (e) => {
        e.persist();
        this.state(() => ({
            [e.target.name]: e.target.value,
        }));
    };

    onSubmit = (e) => {
        e.preventDefault();
        this.props.fetchUser(this.state);
    };

    render() {
        return (
            <form onSubmit={this.onSubmit}>
                <div className='enter_form'>
                    <h2>Sign In</h2>
                    <input
                        type='text'
                        name='username'
                        placeholder='Username'
                        onChange={this.handleOnChange}
                    />
                    <input
                        type='password'
                        name='password'
                        placeholder='Password'
                        onChange={this.handleOnChange}
                    />

                    <button type='submit' className='formButton' value='Login'>
                        Sign In
                    </button>

                    <span className='signup'>
                        New User?{' '}
                        <Link className='register' to='/register'>
                            Register
                        </Link>
                    </span>
                </div>
            </form>
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        fetchUser: (userInfo) => dispatch(fetchUser(userInfo)),
    };
};

export default connect(null, mapDispatchToProps)(LoginForm);
