import React, { Component } from 'react';

import Footer from '../footer';
import Header from '../header';
import AllSections from '../all-sections';
import LoginPage from '../login-page';
import RegisterPage from '../register-page';
import PrivatePage from '../private-page';

import { connect } from 'react-redux';
import { autoLogin } from '../../actions/userActions';

// import GSAPcomponent from '../GSAPcomponent';
import { BrowserRouter as Router, Route } from 'react-router-dom';

// Full Application
class App extends Component {
    componentDidMount() {
        this.props.autoLogin();
    }

    render() {
        return (
            <>
                {!this.props.userReducer.loggedIn ? (
                    <h1>Sign Up or Login!</h1>
                ) : (
                    <h1>Welcome, {this.props.userReducer.user.username}</h1>
                )}
                <Router>
                    <Header />
                    {/* <GSAPcomponent /> */}

                    <Route exact path='/' component={AllSections} />
                    <Route path='/login' component={LoginPage} />
                    <Route path='/register' component={RegisterPage} />
                    <Route path='/private' component={PrivatePage} />

                    <Footer />
                </Router>
            </>
        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
