import { Form } from '../form/form';
import { useDispatch } from 'react-redux';

const Login = () => {
    return <div></div>;
};

export { Login };
