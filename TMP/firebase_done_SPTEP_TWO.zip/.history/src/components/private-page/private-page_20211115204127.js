import React from 'react';
import './private-page.css';

const PrivatePage = () => {
    return (
        <>
            <h1>This Is Private Zone</h1>
        </>
    );
};

export default PrivatePage;
