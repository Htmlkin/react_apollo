import PrivatePage from './private-page';
export default PrivatePage;
