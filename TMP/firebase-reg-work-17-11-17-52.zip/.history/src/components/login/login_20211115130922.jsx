import { Form } from '../form/form';
import { useDispatch } from 'react-redux';

const Login = () => {
    const dispatch = useDispatch();

    return <div></div>;
};

export { Login };
