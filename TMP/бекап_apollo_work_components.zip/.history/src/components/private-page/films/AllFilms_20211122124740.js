import React from 'react';
import Spinner from '../../spinner/Spinner';

const AllFilms = () => {
    return <div></div>;
};

export default AllFilms;
