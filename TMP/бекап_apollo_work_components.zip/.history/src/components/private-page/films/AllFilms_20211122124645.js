import React from 'react';

const AllFilms = () => {
    return <div></div>;
};

export default AllFilms;
