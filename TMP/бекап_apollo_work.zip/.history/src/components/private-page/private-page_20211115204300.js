import React from 'react';
import './private-page.css';

const PrivatePage = () => {
    return (
        <main id='loginContent'>
            <section>
                <h1>This Is Private Zone</h1>
            </section>
        </main>
    );
};

export default PrivatePage;
